Octopuses Are Aliens: an investigation by Megan
PowerPoint, with the narration script in the speaker notes. 19 slides, 1920 x 1080. Audio is not included.
Slides 5, 6, 9, 13 and 17 (Lab Reports) were added to the original deck.
Every fact is real and sourced. Every conclusion is not.
